#!/bin/sh

SQUASH_ORIG=squashfs-mod.sfs
SQUASH=squashfs-mod.bin

if [ ! -s "$1" ]; then
    echo "Please specify a firmware file name"
else
    if [ -d ./squashfs-root ]; then
	offset=`grep --byte-offset --only-matching --text r6cr $1 | grep -oP  '^\d+(?:)'`
	startAddr=`xxd -ps -s $((offset+4)) -l 4 $1 | tr -d '\n'`
	burnAddr=`xxd -ps -s $((offset+8)) -l 4 $1 | tr -d '\n'`
	if [ -z "$offset" ] || [ -z "startAddr" ] || [ -z "$burnAddr" ]; then
	    echo "This firmware is not supported"
	    exit 2
	fi
	echo "Packing..."
	mksquashfs ./squashfs-root/ squashfs-mod.sfs -b 131072 -comp xz > /dev/null 2>&1
	echo "Signing..."
	./cvimg root squashfs-mod.sfs $SQUASH $startAddr $burnAddr > /dev/null 2>&1
	bytes=$(xxd -p -l 4 "$SQUASH")
	if [ "$bytes" = "$(echo -n "root" | xxd -p)" ]; then
	    echo -n "r6cr" | dd conv=notrunc bs=1 count=4 seek=0 of="$SQUASH" > /dev/null 2>&1
	else
	    echo "Squash file incorrect!"
	    exit 1
	fi
	echo "Creating new firware file..."
	new_firmware_name="$(echo "${1%.*}")_mod.$(echo "$1" | echo ${1##*.})"
	cp -v "$1" "$new_firmware_name"
	
	echo "Copying squash to firmware file..."
	dd conv=notrunc bs=1 seek=$offset if=$SQUASH of=$new_firmware_name > /dev/null 2>&1
	echo "Done!"
	rm "$SQUASH"
	rm "$SQUASH_ORIG"
    else
	echo "Squash dir doesn't exist. Please run unpack.sh first"
    fi
fi