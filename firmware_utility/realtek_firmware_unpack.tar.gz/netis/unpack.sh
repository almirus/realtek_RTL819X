#!/bin/sh

SQUASH=squashfs.sfs

if [ ! -s "$1" ]; then
    echo "File is empty"
else
    offset=`grep --byte-offset --only-matching --text r6cr $1 | grep -oP  '^\d+(?:)'`
    if [ -z "$offset" ] || dd if="$1" bs=1 skip="$offset" count=12 2>/dev/null | grep -q "hsqs"; then
	echo "Firware file is incorrect!"
	exit 1
    else
	echo "Magic found at $offset"
	offset=$((offset+16))
	echo "Saving..."
	dd bs=1 skip=$offset if=firmware.bin of=$SQUASH > /dev/null 2>&1
	if [ -f  "$SQUASH" ]; then
		if [ -d ./squashfs-root ]; then
			echo "Squash dir doesn't empty. Already extracted"
			rm "$SQUASH"
		else
			echo "Extracting..."
			unsquashfs squashfs.sfs > /dev/null 2>&1
			echo "Ready! Check squashfs-root DIR"
		fi
	else
		echo "Can't create squashfs!"
		echo 2
	fi
    fi
fi
